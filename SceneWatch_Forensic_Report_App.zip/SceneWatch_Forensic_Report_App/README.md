# SceneWatch — Surveillance Video Review & Report Generator

A beginner-friendly Streamlit prototype for documenting surveillance video review.

## Features
- Upload MP4/AVI/MOV/MKV videos
- Sample frames at configurable intervals
- Flag frame-to-frame motion and possible scene changes
- Review sampled frames and timestamps
- Add analyst observations and case metadata
- Export a text report and CSV timeline
- Optional small Random Forest pattern model trained on analyst-labeled visual features

## Important limitations
This tool is a triage/documentation aid, not a certified forensic system. It does not decide whether a crime occurred, identify people, or infer intent. Pixel changes can be caused by lighting, camera movement, shadows, or compression. Review the original footage manually and preserve the original evidence.

## Run locally
Python 3.10 or 3.11 recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
streamlit run app.py
```

## Deploy on Streamlit Community Cloud
1. Create a GitHub repository.
2. Upload `app.py` and `requirements.txt`.
3. Open Streamlit Community Cloud and deploy the repository, selecting `app.py`.
4. Upload a short test video and verify timestamps against the original.

## How the optional training works
1. Analyze a video.
2. Select a sample number and assign a label (`normal`, `motion_event`, `scene_change`, or `needs_review`).
3. Add multiple examples for each class, ideally from multiple videos.
4. Train/retrain the model.
5. Check its suggestions against footage not used for training.

The model uses four numeric features: brightness, edge density, motion ratio, and frame difference. It learns patterns in those measurements, not criminal behavior. For reliable evaluation, keep separate videos for testing; a few samples from one video are not enough.
