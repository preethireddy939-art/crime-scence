import streamlit as st
import cv2
import numpy as np
import pandas as pd
from datetime import datetime
from pathlib import Path
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report
import pickle
import io

st.set_page_config(page_title="SceneWatch | Video Evidence Report", page_icon="🎥", layout="wide")

st.title("🎥 SceneWatch — Crime Scene & Surveillance Video Report Generator")
st.caption("A beginner-friendly video triage and documentation tool. It flags visual changes for human review; it does NOT determine whether a crime occurred or identify people.")

with st.sidebar:
    st.header("Case details")
    case_id = st.text_input("Case / incident ID", "CASE-001")
    analyst = st.text_input("Analyst / report prepared by", "")
    location = st.text_input("Camera / location", "Camera 1")
    incident_date = st.date_input("Incident date", datetime.now().date())
    st.divider()
    st.caption("Privacy: process only footage you are authorized to review. Keep originals unchanged and record who handled evidence.")

uploaded = st.file_uploader("Upload surveillance video", type=["mp4", "avi", "mov", "mkv", "mpeg", "mpg"])
st.info("Supported analysis: sampled-frame review, motion-change flags, scene-change flags, analyst notes, and a downloadable report. It does not perform face recognition or automatically label criminal activity.")

def video_features(frame, prev_gray=None):
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    brightness = float(np.mean(gray))
    edges = cv2.Canny(gray, 80, 160)
    edge_density = float(np.mean(edges > 0))
    motion_ratio = 0.0
    frame_diff = 0.0
    if prev_gray is not None and prev_gray.shape == gray.shape:
        diff = cv2.absdiff(prev_gray, gray)
        _, thresh = cv2.threshold(diff, 25, 255, cv2.THRESH_BINARY)
        motion_ratio = float(np.mean(thresh > 0))
        frame_diff = float(np.mean(diff) / 255.0)
    return {"brightness": brightness, "edge_density": edge_density,
            "motion_ratio": motion_ratio, "frame_diff": frame_diff}, gray

def analyze_video(file_bytes, sample_every_seconds=1.0, max_width=640):
    temp_path = os.path.join("/tmp", f"scenewatch_{datetime.now().timestamp()}.mp4")
    with open(temp_path, "wb") as f:
        f.write(file_bytes)
    cap = cv2.VideoCapture(temp_path)
    if not cap.isOpened():
        try: os.remove(temp_path)
        except OSError: pass
        raise ValueError("Could not open this video. Try MP4 (H.264) or AVI.")
    fps = cap.get(cv2.CAP_PROP_FPS) or 25.0
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT) or 0)
    duration = total_frames / fps if fps else 0
    interval = max(1, int(fps * sample_every_seconds))
    rows, snapshots = [], []
    prev_gray = None
    frame_index = 0
    progress = st.progress(0)
    while True:
        ok, frame = cap.read()
        if not ok: break
        if frame_index % interval == 0:
            h, w = frame.shape[:2]
            if w > max_width:
                frame = cv2.resize(frame, (max_width, int(h * max_width / w)))
            feats, gray = video_features(frame, prev_gray)
            timestamp = frame_index / fps
            # Transparent, explainable heuristics only; these are review flags, not crime predictions.
            motion_flag = feats["motion_ratio"] >= 0.025
            scene_flag = feats["frame_diff"] >= 0.18
            flags = []
            if motion_flag: flags.append("Motion change")
            if scene_flag: flags.append("Possible scene change")
            rows.append({"timestamp_seconds": round(timestamp, 2),
                         "timestamp_hhmmss": str(pd.to_timedelta(timestamp, unit="s")),
                         **feats, "review_flags": "; ".join(flags) if flags else "No threshold flag"})
            snapshots.append((timestamp, cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)))
            prev_gray = gray
        frame_index += 1
        if total_frames and frame_index % max(1, interval * 10) == 0:
            progress.progress(min(0.99, frame_index / total_frames))
    cap.release()
    try: os.remove(temp_path)
    except OSError: pass
    progress.progress(1.0)
    return pd.DataFrame(rows), snapshots, duration, fps, total_frames

if uploaded:
    sample_rate = st.select_slider("Sample one frame every", options=[0.5, 1.0, 2.0, 3.0, 5.0], value=1.0, format_func=lambda x: f"{x:g} second(s)")
    if st.button("Analyze video", type="primary"):
        try:
            with st.spinner("Sampling video frames and calculating visual-change features…"):
                df, snapshots, duration, fps, total_frames = analyze_video(uploaded.getvalue(), sample_rate)
                st.session_state["analysis"] = {
                    "df": df, "snapshots": snapshots, "filename": uploaded.name,
                    "duration": duration, "fps": fps, "total_frames": total_frames,
                    "sample_rate": sample_rate
                }
        except Exception as e:
            st.error(str(e))

if "analysis" in st.session_state:
    data = st.session_state["analysis"]
    df = data["df"]
    st.subheader("Analysis overview")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Video duration", f"{data['duration']:.1f} sec")
    c2.metric("Frames sampled", len(df))
    c3.metric("Motion flags", int(df["review_flags"].str.contains("Motion change").sum()))
    c4.metric("Possible scene changes", int(df["review_flags"].str.contains("Possible scene change").sum()))
    st.caption(f"File: {data['filename']} · FPS: {data['fps']:.2f} · Frames in original: {data['total_frames']}")
    st.subheader("Timeline of review flags")
    flagged = df[df["review_flags"] != "No threshold flag"]
    if len(flagged):
        st.dataframe(flagged, use_container_width=True, hide_index=True)
    else:
        st.write("No sampled frames crossed the current visual-change thresholds. This does not prove that nothing happened.")
    with st.expander("All sampled frame measurements"):
        st.dataframe(df, use_container_width=True, hide_index=True)
    st.subheader("Review sampled frames")
    if data["snapshots"]:
        idx = st.slider("Sample number", 0, len(data["snapshots"])-1, 0)
        ts, image = data["snapshots"][idx]
        st.image(image, caption=f"Sample at {ts:.2f} seconds", use_container_width=True)
        st.caption("Use the timestamp to locate the moment in the original video. Exported snapshots are review aids, not substitutes for original evidence.")

    st.subheader("Analyst observations")
    notes = st.text_area("Record objective observations (what is visible, time, uncertainty, follow-up needed)", placeholder="Example: At 00:00:12, a moving shape enters the left side of the frame. Identity and intent are unknown.")
    incident_type = st.selectbox("Analyst-assigned event category", [
        "Unreviewed", "Routine activity", "Person/figure visible", "Vehicle visible",
        "Object moved", "Possible unauthorized entry (needs verification)",
        "Property damage suspected (needs verification)", "Other"
    ])
    confidence = st.select_slider("Analyst confidence in these notes", options=["Low", "Medium", "High"], value="Low")
    evidence_ref = st.text_input("Evidence reference / original file hash (optional)", "")
    st.caption("The event category is entered by the analyst. The app does not infer identity, intent, or criminality.")

    # Training area: users label sampled observations and train a lightweight model on numeric visual features.
    st.subheader("Train a pattern model (optional)")
    st.write("To teach the app patterns, review samples and label them. Add multiple examples from different videos for each class. The model learns only the visual measurements below—not the meaning of a crime.")
    label_default = st.selectbox("Label the currently displayed sample", ["normal", "motion_event", "scene_change", "needs_review"])
    if st.button("Add current sample to training examples"):
        ts, image = data["snapshots"][idx]
        row = df.iloc[idx]
        item = {"brightness": row["brightness"], "edge_density": row["edge_density"],
                "motion_ratio": row["motion_ratio"], "frame_diff": row["frame_diff"], "label": label_default}
        existing = st.session_state.get("training_rows", [])
        existing.append(item)
        st.session_state["training_rows"] = existing
        st.success(f"Added sample at {ts:.2f}s as '{label_default}'.")
    training_rows = st.session_state.get("training_rows", [])
    if training_rows:
        train_df = pd.DataFrame(training_rows)
        st.dataframe(train_df, use_container_width=True, hide_index=True)
        if st.button("Train / retrain pattern model"):
            if train_df["label"].nunique() < 2 or train_df["label"].value_counts().min() < 2:
                st.warning("Add at least 2 labeled samples for each of at least 2 classes before training.")
            else:
                X = train_df[["brightness", "edge_density", "motion_ratio", "frame_diff"]]
                y = train_df["label"]
                model = RandomForestClassifier(n_estimators=120, random_state=42, class_weight="balanced")
                model.fit(X, y)
                st.session_state["pattern_model"] = model
                st.session_state["pattern_model_classes"] = list(model.classes_)
                st.success(f"Model trained on {len(train_df)} labeled samples and {y.nunique()} classes.")
        if st.session_state.get("pattern_model") is not None:
            model = st.session_state["pattern_model"]
            pred_df = df[["brightness", "edge_density", "motion_ratio", "frame_diff"]].copy()
            pred_df["model_pattern_suggestion"] = model.predict(pred_df)
            st.write("Model suggestions for this video (human review required):")
            st.dataframe(pred_df, use_container_width=True, hide_index=True)
            model_bytes = pickle.dumps(model)
            st.download_button("Download trained model", model_bytes, file_name="scenewatch_pattern_model.pkl", mime="application/octet-stream")
    else:
        st.caption("No training examples added yet. The app's basic motion flags work without training.")

    st.subheader("Generate report")
    report_text = f"""SCENEWATCH — SURVEILLANCE VIDEO REVIEW REPORT
Case / incident ID: {case_id}
Prepared by: {analyst or 'Not provided'}
Camera / location: {location}
Incident date: {incident_date}
Source video filename: {data['filename']}
Evidence reference / hash: {evidence_ref or 'Not provided'}
Video duration: {data['duration']:.2f} seconds
Reported FPS: {data['fps']:.2f}
Sampling interval: {data['sample_rate']} second(s)
Frames sampled: {len(df)}
Motion-change flags: {int(df['review_flags'].str.contains('Motion change').sum())}
Possible scene-change flags: {int(df['review_flags'].str.contains('Possible scene change').sum())}
Analyst-assigned category: {incident_type}
Analyst confidence: {confidence}

ANALYST OBSERVATIONS
{notes or 'No notes provided.'}

FLAGGED TIMELINE
{flagged.to_string(index=False) if len(flagged) else 'No sampled frames crossed the configured thresholds.'}

METHOD AND LIMITATIONS
The video was sampled at the selected interval. Motion and possible scene-change flags are based on frame-to-frame pixel differences and simple thresholds. They may be caused by lighting, camera movement, compression, shadows, or ordinary activity. They are not proof of a crime and may miss events between sampled frames. Model suggestions, if used, are based only on analyst-labeled visual feature examples and require independent human verification. No face recognition or identity matching is performed.

EVIDENCE HANDLING
Preserve the original file unchanged. Document acquisition source, date/time, timezone, hash, transfer history, and authorized handlers according to your organization's evidence procedure. This report is a triage aid and is not a certified forensic examination.
"""
    st.text_area("Report preview", report_text, height=320)
    st.download_button("Download report (.txt)", report_text, file_name=f"{case_id}_video_review_report.txt", mime="text/plain")
    csv_bytes = df.to_csv(index=False).encode("utf-8")
    st.download_button("Download timeline (.csv)", csv_bytes, file_name=f"{case_id}_timeline.csv", mime="text/csv")
else:
    st.subheader("How to use")
    st.markdown("""
1. Enter case details in the sidebar.
2. Upload a video file and click **Analyze video**.
3. Review flagged timestamps and sampled frames in the original footage.
4. Write factual observations and identify uncertainty.
5. Download the report and timeline.
6. Optional: label multiple samples to train a small pattern model. Add varied examples from several videos; test on separate footage before relying on it.
""")

st.divider()
st.caption("SceneWatch prototype · For lawful, authorized review only · Keep originals and verify all findings manually.")
